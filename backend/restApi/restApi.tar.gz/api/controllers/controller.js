'use strict';
var tz=require('moment-timezone'),
  mongoose = require('mongoose'),
  Log = mongoose.model('chatlog'),
  moment = require('moment');


                //////////////////
                //  RETRIEVE    //
                //////////////////

exports.getConversation = function(req,res) {
  Log.find({"conversationId":req.params.id}, function(err,item){
    if(err)
      res.send(err);
    res.json(item);
  });
};

//get IDs of conversations that have userfeedback as No or null
exports.getConversationIds = function(req,res) {
  Log.find({"userFeedback":{ $ne: "Yes"}}, {"conversationId":1, _id:0}, {limit:100}, function(err,item){
    if(err)
      res.send(err);
    res.json(item);
  });
};

exports.getChats = function(req,res) {
  Log.find({"conversationId":req.params.id}, {"conversationId":1, "text":1, "localTimeStamp":1, "textId":1, "from":1, "inputHint":1, "userFeedback":1, "attachments":1, _id:0}, function(err,item){
    if(err)
      res.send(err);
    res.json(item);
  });
}

exports.getChatsIntegrated = function(req,res) {
  Log.find({}, {"conversationId":1, "text":1, "localTimeStamp":1, "textId":1, "from":1, "inputHint":1, "userFeedback":1, "attachments":1, _id:0}, {limit:1000},function(err,item){
    if(err)
      res.send(err);
    res.json(item);
  });
}

exports.getGraphData = function(req,res) {

  var timediff = {"months":0,"days":0};

  if(req.params.time ==="y")
    timediff.months = 12;
  else if(req.params.time ==="m")
    timediff.months = 1;
  else if(req.params.time ==="w")
    timediff.days = 7;
  else if(req.params.time ==="d")
    timediff.days = 1;

  Log.find({"localTimeStamp":{"$gte":new Date(moment().subtract(timediff.months,'M').subtract(timediff.days,'d').toISOString())},"inputHint":"noAnswerFound"}).count(function(err,item){
    if(err)
      res.send(err);
    var noAnswer = item;
    Log.find({"localTimeStamp":{"$gte":new Date(moment().subtract(timediff.months,'M').subtract(timediff.days,'d').toISOString())},"userFeedback":"No"}).count(function(err,item){
      if(err)
        res.send(err);
      var no = item;
      Log.find({"localTimeStamp":{"$gte":new Date(moment().subtract(timediff.months,'M').subtract(timediff.days,'d').toISOString())},"userFeedback":"Yes"}).count(function(err,item){
        if(err)
          res.send(err);
        var yes = item;
        var response = {noAnswer,no,yes};
        res.json(response);
      });
    });
  });
}

exports.getGraphDataAggregated = function(req,res) {
      var timediff = {"months":0,"days":0};
      if(req.params.time ==="y")
      {
            timediff.months = 12;

            Log.find({"localTimeStamp":{"$gte":new Date(moment().subtract(timediff.months,'M').subtract(timediff.days,'d').toISOString())},"$or":[{"inputHint":"noAnswerFound"},{"userFeedback":"No"},{"userFeedback":"Yes"}]} ,function(err,item){
            if(err)
              res.send(err);

            var dateLimit2 = moment(JSON.parse(JSON.stringify(item))[0].localTimeStamp).add(1, 'months').startOf('month');
            var initialMonth = moment(JSON.parse(JSON.stringify(item))[0].localTimeStamp).month();
            var response = item;
            var month=[[0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0]]; //NoAnswer,no,yes
            var currenttime = moment();
            var weekOfTheMonth = Math.ceil(currenttime.date() / 7); //extract the weekOfTheMonth
            var dayOfTheWeek = currenttime.day();
            var dateLimit = moment().subtract(dayOfTheWeek,'d').subtract((weekOfTheMonth-1)*7,'d').subtract(11,'M');
            var j=initialMonth;//start from initial month
            
            for(var i=0;i<response.length;i++)
            {
                  if(moment(JSON.parse(JSON.stringify(response))[i].localTimeStamp).isSameOrBefore(dateLimit2))
                  {
                        if(response[i].inputHint === "noAnswerFound")
                            month[0][j]=month[0][j]+1;
                        else if(response[i].userFeedback === "No")
                            month[1][j]=month[1][j]+1;
                        else if(response[i].userFeedback === "Yes")
                            month[2][j]=month[2][j]+1;
                  }
                  else
                    {
                        //console.log("\n\n" + JSON.parse(JSON.stringify(response))[i].localTimeStamp);
                        dateLimit2=dateLimit2.add(1,'M');
                        j=j+1;
                        i=i-1;
                        if(j==12)
                          break;
                    }
            }

            res.json(month);
          });
      }
        
      else if(req.params.time ==="m")
      {
            timediff.months = 1;

            Log.find({"localTimeStamp":{"$gte":new Date(moment().subtract(timediff.months,'M').subtract(timediff.days,'d').toISOString())},"$or":[{"inputHint":"noAnswerFound"},{"userFeedback":"No"},{"userFeedback":"Yes"}]} ,function(err,item){
            if(err)
              res.send(err);

            var response = item;
            var week=[[0,0,0,0],[0,0,0,0],[0,0,0,0]];
            var currenttime = moment();
            var dayOfTheWeek = currenttime.day();
            var dateLimit = moment().subtract(dayOfTheWeek,'d').subtract(14,'d');
            var j=0;//start from 1st week

            for(var i=0;i<response.length;i++)
            {
                  if(moment(JSON.parse(JSON.stringify(response))[i].localTimeStamp).isSameOrBefore(dateLimit))
                  {
                        if(response[i].inputHint === "noAnswerFound")
                            week[0][j]=week[0][j]+1;
                        else if(response[i].userFeedback === "No")
                            week[1][j]=week[1][j]+1;
                        else if(response[i].userFeedback === "Yes")
                            week[2][j]=week[2][j]+1;
                  }
                  else
                    {
                        dateLimit=dateLimit.add(7,'d');
                        j=j+1;
                        i=i-1;
                        if(j==4)
                          break;
                    }
            }

            res.json(week);
          });
      }
        
      else if(req.params.time ==="w")
      {
            timediff.days = 7;

            Log.find({"localTimeStamp":{"$gte":new Date(moment().subtract(timediff.months,'M').subtract(timediff.days,'d').toISOString())},"$or":[{"inputHint":"noAnswerFound"},{"userFeedback":"No"},{"userFeedback":"Yes"}]} ,function(err,item){
            if(err)
              res.send(err);
            //console.log(item.length);
            var dateLimit2 = moment(JSON.parse(JSON.stringify(item))[0].localTimeStamp).add(1, 'day').startOf('day');
            var initialDay = moment(JSON.parse(JSON.stringify(item))[0].localTimeStamp).day();
            var response = item;
            var day=[[0,0,0,0,0,0,0],[0,0,0,0,0,0,0],[0,0,0,0,0,0,0]];
            var currenttime = moment();
            
            var j=initialDay;//start from initial month
            j=0;
            for(var i=0;i<response.length;i++)
            {
                  //console.log(JSON.parse(JSON.stringify(response))[i].localTimeStamp+"   "+dateLimit2.toISOString());
                  if(moment(JSON.parse(JSON.stringify(response))[i].localTimeStamp).isSameOrBefore(dateLimit2))
                  {
                        if(response[i].inputHint === "noAnswerFound")
                            day[0][j]=day[0][j]+1;
                        else if(response[i].userFeedback === "No")
                            day[1][j]=day[1][j]+1;
                        else if(response[i].userFeedback === "Yes")
                            day[2][j]=day[2][j]+1;
                  }
                  else
                    {
                        //console.log("\n\n" + JSON.parse(JSON.stringify(response))[i].localTimeStamp);
                        dateLimit2=dateLimit2.add(1,'d');
                        j=j+1;
                        i=i-1;
                        if(j==7)
                          break;
                        //day[j]=day[j]+1;
                    }
            }

            res.json(day);
          });
      }
        
      else if(req.params.time ==="d")
      {
            timediff.days = 1;

            Log.find({"localTimeStamp":{"$gte":new Date(moment().subtract(timediff.months,'M').subtract(timediff.days,'d').toISOString())},"$or":[{"inputHint":"noAnswerFound"},{"userFeedback":"No"},{"userFeedback":"Yes"}]} ,function(err,item){
            if(err)
              res.send(err);

            var response = item;
            var hour=[[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]];
            var currenttime = moment();
            var dateLimit = moment().subtract(23,'h');
            var j=0;//start from 1st hour

            for(var i=0;i<response.length;i++)
            {
                  if(moment(JSON.parse(JSON.stringify(response))[i].localTimeStamp).isSameOrBefore(dateLimit))
                  {
                        if(response[i].inputHint === "noAnswerFound")
                            hour[0][j]=hour[0][j]+1;
                        else if(response[i].userFeedback === "No")
                            hour[1][j]=hour[1][j]+1;
                        else if(response[i].userFeedback === "Yes")
                            hour[2][j]=hour[2][j]+1;
                  }
                  else
                    {
                        dateLimit=dateLimit.add(1,'h');
                        j=j+1;
                        i=i-1;
                        if(j==24)
                          break;
                    }
            }
            res.json(hour);
          });
      }     
}


                //////////////////
                //    CREATE    //
                //////////////////

exports.postUser = function(req,res) {
  console.log(req.body.body);
  var newuser = new User(JSON.parse(req.body.body));
  newuser.save(function(err,data){
    if(err)
      res.send(err);
    res.json(data);
  });
};

exports.postCourse = function(req,res) {
  console.log(req.body.body);
  var newcourse = new Course(JSON.parse(req.body.body));
  Course.find({}, function(err,item){
      var courses = item;
      var lastid = courses[courses.length-1].courseid;
      newcourse.courseid = lastid+1;
      newcourse.save(function(err,data){
      if(err)
        res.send(err);
      res.json(data);
    });
  });
};

exports.postAdmin = function(req,res) {
  console.log(req.body.body);
  var newadmin = new Admin(JSON.parse(req.body.body));
  newadmin.save(function(err,data){
    if(err)
      res.send(err);
    res.json(data);
  });
};

exports.postInvol = function(req,res) {
  console.log(req.body.body);
  var newinvol = new Invol(JSON.parse(req.body.body));
  var courseid = newinvol.courseid;
  var contentqueue = [];
  Course.find({"courseid":courseid}, function(err,item){
    if(err)
      console.log(err);
    for(var i =0; i<item[0].content.length; i++)
    {
      var timediff = item[0].content[i].timediff; //in format : {'months':11,'days':30,'hours':23,'minutes':59}
      var currenttime = moment();
      var contenttime = currenttime.clone().tz('Asia/Kolkata').add(timediff.months,'M').add(timediff.days,'d').add(timediff.hours,'h')
      .add(timediff.minutes,'m');
      console.log("Current Time is: " + contenttime.toDate());
      contentqueue.push({"contentno":item[0].content[i].contentno, "time":contenttime.toDate()});
    }
    newinvol.messageQueue = contentqueue;
    newinvol.save(function(err,data)
    {
      if(err)
        res.send(err);
      res.json(data);
    });
  });
};

                //////////////////
                //    UPDATE    //
                //////////////////


exports.updateUser = function(req,res) {
  console.log(req.body.body);
  var queryid = JSON.parse(req.body.body);
  var query = {'userid':queryid.userid};
  var newobj = JSON.parse(req.body.body);
  User.findOneAndUpdate(query, newobj, {upsert:true},function(err,data){
    if(err)
      res.send(err);
    res.json(data);
  });
};

exports.updateAdmin = function(req,res) {
  console.log(req.body.body);
  var queryid = JSON.parse(req.body.body);
  var query = {'adminid':queryid.adminid};
  var newobj = JSON.parse(req.body.body);
  Admin.findOneAndUpdate(query, newobj, {upsert:true},function(err,data){
    if(err)
      res.send(err);
    res.json(data);
  });
};

exports.updateCourse = function(req,res) {
  console.log(req.body.body);
  var queryid = JSON.parse(req.body.body);
  var query = {'courseid':queryid.courseid};
  var newobj = JSON.parse(req.body.body);
  Course.findOneAndUpdate(query, newobj, {upsert:true},function(err,data){
    if(err)
      res.send(err);
    res.json(data);
  });
};

exports.insertContent = function(req,res) {
  console.log(req.body.body);
  var queryid = JSON.parse(req.body.body);
  var query = {"courseid":queryid.courseid};
  //console.log("Query = " + query + "queryid.courseid = " + queryid.courseid);
  var desc = queryid.contentdesc;
  var url = queryid.link;
  var newcontent = {"contentdesc":desc,"link":queryid.link, "imgurl":queryid.imgurl, "timediff":queryid.timediff};
  Course.update(query,{$push: {"content":newcontent}},{upsert:true},function(err,data){
        if(err){
                res.send(err);
        }else{
                res.json(data);
        }
});
}

exports.updateInvol = function(req,res) {
  console.log(req.body.body);
  var queryid = JSON.parse(req.body.body);
  var query = {'involvementno':queryid.involvementno};
  var newobj = JSON.parse(req.body.body);
  Invol.findOneAndUpdate(query, newobj, {upsert:true},function(err,data){
    if(err)
      res.send(err);
    res.json(data);
  });
};

exports.updateInvolUsingObjID = function(req,res) {
  console.log(req.body.body);
  var queryid = JSON.parse(req.body.body);
  var query = {'_id':queryid._id};
  var newobj = JSON.parse(req.body.body);
  Invol.findOneAndUpdate(query, newobj, {upsert:true},function(err,data){
    if(err)
      res.send(err);
    res.json(data);
  });
};